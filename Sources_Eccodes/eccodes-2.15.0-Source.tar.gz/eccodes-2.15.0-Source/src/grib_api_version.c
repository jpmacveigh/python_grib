const char * grib_get_git_sha1() { return ""; }
